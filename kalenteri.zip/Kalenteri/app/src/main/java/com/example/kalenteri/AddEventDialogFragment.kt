package com.example.kalenteri

class `AddEventDialogFragment.kt` : DialogFragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Lataa dialogin käyttöliittymä
        val view = inflater.inflate(R.layout.dialog_add_event, container, false)

        // Hae komponentit käyttöliittymästä
        val saveEventButton: Button = view.findViewById(R.id.saveEventButton)
        val eventNameEditText: EditText = view.findViewById(R.id.eventName)

        // Määritä toiminto tallennuspainikkeelle
        saveEventButton.setOnClickListener {
            val eventName = eventNameEditText.text.toString()

            if (eventName.isNotEmpty()) {
                // Tallenna tapahtuma, esim. lisää se tietokantaan tai listaasi
                Toast.makeText(context, "Event '$eventName' added!", Toast.LENGTH_SHORT).show()
                dismiss()  // Sulkee dialogin
            } else {
                Toast.makeText(context, "Please enter an event name", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }
}
