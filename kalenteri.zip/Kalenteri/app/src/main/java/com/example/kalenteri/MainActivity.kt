package com.example.kalenteri

import android.os.Bundle
import android.widget.CalendarView
import android.widget.TextView
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import androidx.fragment.app.DialogFragment

class MainActivity : AppCompatActivity() {

    private lateinit var dailySummary: TextView
    private lateinit var calendarView: CalendarView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        calendarView = findViewById(R.id.calendarView)
        dailySummary = findViewById(R.id.dailySummary)

        // Tapahtumien kuuntelu
        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            val date = "$dayOfMonth/${month + 1}/$year"
            showDailyEvents(date) // Näytetään tapahtumat valitulle päivälle
        }

        // Lisätään tapahtumien luontipainike
        val addEventButton: Button = findViewById(R.id.addEventButton)
        addEventButton.setOnClickListener {
            // Avaa tapahtuman lisäysdialogi (tai uusi aktiviteetti)
            val dialog = `AddEventDialogFragment.kt`()
            dialog.show(supportFragmentManager, "AddEventDialog")
        }
    }

    // Päivittäisten tapahtumien näyttäminen
    private fun showDailyEvents(date: String) {
        // Tässä vaiheessa voi hakea päivittäiset tapahtumat tietokannasta
        dailySummary.text = "Daily Events for $date: \n- Event 1\n- Event 2"  // Esimerkki
    }

    // Lisätään tapahtuma (esimerkkitoiminto)
    fun addEvent(view: View) {
        val dialog = `AddEventDialogFragment.kt`()
        dialog.show(supportFragmentManager, "AddEventDialog")
    }
}

// Esimerkki tapahtuman lisäysdialogista
class AddEventDialogFragment : DialogFragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.dialog_add_event, container, false)

        // Tapahtuman lisäämisen logiikka täällä
        return view
    }
}

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val addEventButton: Button = findViewById(R.id.addEventButton)
        addEventButton.setOnClickListener {
            // Avaa tapahtuman lisäysdialogi
            val dialog = `AddEventDialogFragment.kt`()
            dialog.show(supportFragmentManager, "AddEventDialog")
        }
    }
}
