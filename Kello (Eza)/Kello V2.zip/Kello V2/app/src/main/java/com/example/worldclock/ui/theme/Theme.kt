package com.example.worldclock.ui.theme

import android.app.Activity
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryColor,
    surface = SurfaceColor,
    onBackground = OnBackgroundColor,
    secondaryContainer = SecondaryContainerColor,
    onSurfaceVariant = OnSurfaceVariantColor,
)

@Composable
fun WorldClockTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current

    // Animate color transitions
    val primaryColor by animateColorAsState(
        targetValue = DarkColorScheme.primary,
        animationSpec = tween(durationMillis = 500),
        label = "primary"
    )

    val surfaceColor by animateColorAsState(
        targetValue = DarkColorScheme.surface,
        animationSpec = tween(durationMillis = 500),
        label = "surface"
    )

    if (!view.isInEditMode) {
        SideEffect {
            (view.context as Activity).window.statusBarColor = primaryColor.toArgb()
            (view.context as Activity).window.navigationBarColor = AndroidNavigationBarColor.toArgb()
        }
    }

    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}