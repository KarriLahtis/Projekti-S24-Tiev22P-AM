package com.example.worldclock

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import com.example.worldclock.ui.AnalogClockComponent
import com.example.worldclock.ui.theme.WorldClockTheme
import kotlinx.coroutines.delay
import java.util.Calendar
import java.util.TimeZone

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var selectedTimeZone by remember { mutableStateOf("Europe/Helsinki") }
            var hour by remember { mutableStateOf("0") }
            var minute by remember { mutableStateOf("0") }
            var second by remember { mutableStateOf("0") }
            var amOrPm by remember { mutableStateOf("AM") }

            val timeZones = mapOf(
                "Helsinki" to "Europe/Helsinki",
                "New York" to "America/New_York",
                "Tokyo" to "Asia/Tokyo",
                "Amsterdam" to "Europe/Amsterdam",
                "Berlin" to "Europe/Berlin",
                "Hong Kong" to "Asia/Hong_Kong"
            )

            LaunchedEffect(selectedTimeZone) {
                while (true) {
                    val calendar = Calendar.getInstance(TimeZone.getTimeZone(selectedTimeZone))

                    hour = calendar.get(Calendar.HOUR).run {
                        if (this == 0) "12" else if (this < 10) "0$this" else "$this"
                    }
                    minute = calendar.get(Calendar.MINUTE).run {
                        if (this < 10) "0$this" else "$this"
                    }
                    second = calendar.get(Calendar.SECOND).run {
                        if (this < 10) "0$this" else "$this"
                    }
                    amOrPm = if (calendar.get(Calendar.AM_PM) == Calendar.AM) "AM" else "PM"

                    delay(1000)
                }
            }

            WorldClockTheme {
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text("World Clock") },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                titleContentColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                ) { padding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Spacer(modifier = Modifier.height(16.dp))

                        TimeZoneSelector(
                            selectedTimeZone = selectedTimeZone,
                            timeZones = timeZones,
                            onTimeZoneSelected = { selectedTimeZone = it }
                        )

                        Spacer(modifier = Modifier.height(32.dp))

                        AnalogClockComponent(
                            hour = hour.toIntOrNull() ?: 0,
                            minute = minute.toIntOrNull() ?: 0,
                            second = second.toIntOrNull() ?: 0
                        )

                        Spacer(modifier = Modifier.height(32.dp))

                        DigitalClockDisplay(
                            hour = hour,
                            minute = minute,
                            amOrPm = amOrPm,
                            cityName = timeZones.entries.find { it.value == selectedTimeZone }?.key ?: ""
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimeZoneSelector(
    selectedTimeZone: String,
    timeZones: Map<String, String>,
    onTimeZoneSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it },
        modifier = Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
    ) {
        TextField(
            value = timeZones.entries.find { it.value == selectedTimeZone }?.key ?: "",
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor()
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            timeZones.forEach { (city, zone) ->
                DropdownMenuItem(
                    text = { Text(city) },
                    onClick = {
                        onTimeZoneSelected(zone)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun DigitalClockDisplay(
    hour: String,
    minute: String,
    amOrPm: String,
    cityName: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(16.dp)
    ) {
        Text(
            text = "$hour:$minute $amOrPm",
            style = MaterialTheme.typography.titleLarge
        )
        Text(
            text = cityName,
            style = MaterialTheme.typography.bodyMedium.merge(
                TextStyle(
                    color = MaterialTheme.colorScheme.onBackground.copy(
                        alpha = 0.6f
                    )
                )
            )
        )
    }
}

