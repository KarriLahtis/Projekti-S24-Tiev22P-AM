package com.example.worldclock.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.example.worldclock.ui.theme.*
import kotlin.math.min
import androidx.compose.animation.core.*

@Composable
fun AnalogClockComponent(
    hour: Int,
    minute: Int,
    second: Int,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "clock")
    
    val secondRotation = infiniteTransition.animateFloat(
        initialValue = second * 6f,
        targetValue = (second + 60) * 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(60000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "seconds"
    )
    
    val minuteRotation = infiniteTransition.animateFloat(
        initialValue = minute * 6f + second * 0.1f,
        targetValue = (minute + 60) * 6f + second * 0.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3600000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "minutes"
    )
    
    val hourRotation = infiniteTransition.animateFloat(
        initialValue = hour * 30f + minute * 0.5f,
        targetValue = (hour + 12) * 30f + minute * 0.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(43200000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "hours"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize(fraction = 0.6f)
            .aspectRatio(1f)
            .shadowCircular(
                offsetX = (-38).dp,
                offsetY = 0.dp,
                blurRadius = 54.dp,
                color = AnalogClockOuterBoxShadow1
            )
            .shadowCircular(
                offsetX = 30.dp,
                offsetY = 0.dp,
                blurRadius = 54.dp,
                color = AnalogClockOuterBoxShadow2
            )
            .clip(CircleShape)
            .background(AnalogClockOuterBoxColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize(fraction = 0.85f)
                .aspectRatio(1f)
                .shadowCircular(
                    offsetX = 4.dp,
                    offsetY = 0.dp,
                    blurRadius = 10.dp,
                    color = AnalogClockInnerBoxShadow
                )
                .clip(CircleShape)
                .background(AnalogClockInnerBoxColor)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val diameter = min(size.width, size.height) * 0.9f
                val radius = diameter / 2

                // Draw hour markers
                repeat(12) {
                    rotate(it * 30f) {
                        drawLine(
                            color = AnalogClockHourHandColor,
                            start = center + Offset(0f, -radius),
                            end = center + Offset(0f, -radius + 20f),
                            strokeWidth = 3f,
                            cap = StrokeCap.Round
                        )
                    }
                }

                // Hour hand
                rotate(hourRotation.value) {
                    drawLine(
                        color = AnalogClockHourHandColor,
                        start = center,
                        end = center + Offset(0f, -radius * 0.5f),
                        strokeWidth = 5f,
                        cap = StrokeCap.Round
                    )
                }

                // Minute hand
                rotate(minuteRotation.value) {
                    drawLine(
                        color = AnalogClockMinuteHandColor,
                        start = center,
                        end = center + Offset(0f, -radius * 0.7f),
                        strokeWidth = 3f,
                        cap = StrokeCap.Round
                    )
                }

                // Second hand
                rotate(secondRotation.value) {
                    drawLine(
                        color = AnalogClockSecondHandColor,
                        start = center,
                        end = center + Offset(0f, -radius * 0.8f),
                        strokeWidth = 2f,
                        cap = StrokeCap.Round
                    )
                }

                // Center dot
                drawCircle(
                    color = AnalogClockSecondHandColor,
                    radius = 8f,
                    center = center
                )
            }
        }
    }
}