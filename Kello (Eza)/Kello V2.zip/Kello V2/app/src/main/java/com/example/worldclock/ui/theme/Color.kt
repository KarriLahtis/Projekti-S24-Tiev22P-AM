package com.example.worldclock.ui.theme

import androidx.compose.ui.graphics.Color

// Main colors
val PrimaryColor = Color(0xFF1A1A1A)         // Dark background
val SurfaceColor = Color(0xFF2D2D2D)         // Slightly lighter dark
val OnBackgroundColor = Color(0xFF0D47A1)    // Deep blue accent
val SecondaryContainerColor = Color(0xFF424242)  // Dark grey
val OnSurfaceVariantColor = Color(0xFF90CAF9)    // Light blue accent

// Clock colors
val AnalogClockOuterBoxShadow1 = Color.White.copy(alpha = 0.05f)
val AnalogClockOuterBoxShadow2 = Color(0x48000000)
val AnalogClockOuterBoxShadow3 = Color.White.copy(alpha = 0.1f)
val AnalogClockOuterBoxShadow4 = Color(0xFF1A1A1A)
val AnalogClockOuterBoxColor = Color(0xFF2D2D2D)

val AnalogClockInnerBoxShadow = Color(0x59000000)
val AnalogClockInnerBoxColor = Color(0xFF363636)

val AnalogClockHourHandColor = Color(0xFF90CAF9)    // Light blue
val AnalogClockMinuteHandColor = Color(0xFF64B5F6)  // Medium blue
val AnalogClockSecondHandColor = Color(0xFF2196F3)  // Darker blue

val NavigationBarShadowColor = Color(0x40000000)
val NavigationBarColor = Color(0xFF1A1A1A)          // Dark
val AndroidNavigationBarColor = Color(0xFF000000)    // Pure black