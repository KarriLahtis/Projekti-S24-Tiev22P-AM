package com.example.worldclock.ui.theme

import androidx.compose.ui.graphics.Color

// Main colors
val PrimaryColor = Color(0xFF2196F3)         // Changed to blue
val SurfaceColor = Color(0xFFF5F5F5)         // Light grey background
val OnBackgroundColor = Color(0xFF1976D2)    // Darker blue
val SecondaryContainerColor = Color(0xFF03A9F4)  // Light blue
val OnSurfaceVariantColor = Color(0xFF0D47A1)    // Deep blue

// Clock colors
val AnalogClockOuterBoxShadow1 = Color.White.copy(alpha = 0.41f)
val AnalogClockOuterBoxShadow2 = Color(0x48C7D6EA)
val AnalogClockOuterBoxShadow3 = Color.White
val AnalogClockOuterBoxShadow4 = Color(0xffC4D4E7)
val AnalogClockOuterBoxColor = Color(0xffE7EEFB)

val AnalogClockInnerBoxShadow = Color(0x59C4D4E7)
val AnalogClockInnerBoxColor = Color(0xffEDF1FB)

val AnalogClockHourHandColor = Color(0xFF0D47A1)    // Deep blue
val AnalogClockMinuteHandColor = Color(0xFF1976D2)  // Medium blue
val AnalogClockSecondHandColor = Color(0xFF03A9F4)  // Light blue

val NavigationBarShadowColor = Color(0xBFC4D4E7)
val NavigationBarColor = Color(0xFFE3F2FD)          // Very light blue
val AndroidNavigationBarColor = Color(0xFF1565C0)    // Dark blue