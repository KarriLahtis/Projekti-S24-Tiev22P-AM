package com.example.kalenteri

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.DialogFragment

class AddEventDialogFragment : DialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Lataa dialogin käyttöliittymä
        val view = inflater.inflate(R.layout.dialog_add_event, container, false)

        // Hae käyttöliittymän komponentit
        val saveEventButton: Button = view.findViewById(R.id.saveEventButton)
        val eventNameEditText: EditText = view.findViewById(R.id.eventName)

        // Määritä toiminto tallennuspainikkeelle
        saveEventButton.setOnClickListener {
            val eventName = eventNameEditText.text.toString()

            if (eventName.isNotEmpty()) {
                Toast.makeText(context, "$eventName added!", Toast.LENGTH_SHORT).show()
                dismiss() // Sulje dialogi
            } else {
                Toast.makeText(context, "Please enter an event name", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }
}
