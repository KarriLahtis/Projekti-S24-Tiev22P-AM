package com.example.ajastin

import android.os.CountDownTimer
import androidx.lifecycle.ViewModel

class MainActivityTimerViewModel : ViewModel() {
    lateinit var timer: CountDownTimer

    private val remaining_second = MutableLiveData<Int>()
    val _second: LiveData<Int>
        get() = remaining_second

    private var _finished = MutableLiveData<Boolean>()
    val finished : LiveData<Boolean>
        get() = _finished

    var timerValue = MutableLiveData<Long>()

    fun start(){


        timer = object : CountDownTimer(timerValue.value!!.toLong(), 1000){
            override fun onTick(p0: Long) {
                val remainingTime = p0/1000
                remaining_second.value = remainingTime.toInt()
            }

            override fun onFinish() {
                _finished.value = true
            }

        }.start()
    }
    fun stop(){
        timer.cancel()

    }
}