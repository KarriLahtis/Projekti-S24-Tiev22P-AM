package com.example.ajastin

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val txtViewResultShow = findViewById<TextView>(R.id.result_show)
        val edtInput = findViewById<EditText>(R.id.edt_input)
        val btnStart = findViewById<Button>(R.id.btn_start)
        val btnStop = findViewById<Button>(R.id.btn_stop)

        val maViewModel = ViewModelProvider(this).get(MainActivityTimerViewModel::class.java)

        maViewModel._second.observe(this, Observer { seconds ->
            txtViewResultShow.text = "$seconds"
        })

        maViewModel.finished.observe(this, Observer { check ->
            if (check) {
                Toast.makeText(this, "Finished", Toast.LENGTH_SHORT).show()
            }
        })

        btn_start.setOnClickListener {
            if (edtInput.text.isEmpty()) {
                Toast.makeText(this, "Enter time")
            }
        }else{
                maViewModel.timerValue.value = edtInput.text.toString().toLong() * 1000
                maViewModel.start()
        }

        
    }
}