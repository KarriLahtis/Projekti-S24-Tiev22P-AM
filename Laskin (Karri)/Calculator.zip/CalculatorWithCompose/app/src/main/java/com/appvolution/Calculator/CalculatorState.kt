package com.appvolution.Calculator

data class CalculatorState(
    val number1: String = "",
    val number2: String = "",
    var operatorPressed: Boolean = false,
    val operation: CalculatorOperations? = null
)


